/**Program: WelcomeClass
 * File: WelcomeClass.java
 * Summary: Prints author's own information to the console
 * Author: Bibata Rabba Idi
 * Date: October 22, 2017
 **/
public class WelcomeClass {


    public static void main(String[] args) {
        System.out.println("My name is Bibata Rabba Idi");
        System.out.println("My favorite color is white");
        System.out.println("If I won the lottery, I would help others");
        
    }
    
}
